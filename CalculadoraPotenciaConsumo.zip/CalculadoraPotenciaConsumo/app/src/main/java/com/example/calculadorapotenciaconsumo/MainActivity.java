package com.example.calculadorapotenciaconsumo;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editPotencia;
    private EditText editHoras;
    private EditText editPrecoKWH;
    private TextView textResultado;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editPotencia = findViewById(R.id.editPotencia);
        editHoras = findViewById(R.id.editHoras);
        editPrecoKWH = findViewById(R.id.editPrecoKWH);
        textResultado = findViewById(R.id.textResultado);
        Button btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularConsumo();
            }
        });
    }

    private void calcularConsumo() {
        double potencia = Double.parseDouble(editPotencia.getText().toString());
        double horas = Double.parseDouble(editHoras.getText().toString());
        double precoKWH = Double.parseDouble(editPrecoKWH.getText().toString());

        double consumoEnergia = (potencia * horas) / 1000;

        double custoEnergia = consumoEnergia * precoKWH;

        textResultado.setText(String.format("Consumo: %.2f kWh\nCusto: R$ %.2f", consumoEnergia, custoEnergia));
    }
}